#include "engine/scenes/scene.hpp"
#include "engine/engine.hpp"

#include "engine/scenes/sprite.hpp"



class Scene: public BaseScene{
private:
    Sprite sprite;
public:
    ~Scene(){

    }

    void on_init()override{
        sprite.set_color(sf::Color::Red);
        sprite.set_size(300,400);

        object_introduce(&sprite);
    }

    void on_update(float dt)override{
        
    }
};

Engine * engine;

int main(){
    engine = new Engine();

    engine->init();
    engine->show_fps(true);
    engine->set_entry_scene(new Scene,"MainScene");
    engine->start();

}
